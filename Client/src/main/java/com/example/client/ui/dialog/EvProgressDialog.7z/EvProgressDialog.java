package com.example.client.ui.dialog;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Message;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.TextView;

public class EvProgressDialog extends Dialog {

    private static final int PERIOD_UPDATE_LOADING_VIEW = 125;
    private static final int MSG_UPDATE_LOADING_VIEW = 0x0A0B0C0D;

    private Context mContext;
    private Handler mHandler;

    private LinearLayout mParentView;
    private EvProgressView mEvProgressView;
    private TextView mTextView;

    private int mCount = 0;

    public EvProgressDialog(Context context) {
        super(context);
        mContext = context;
        mParentView = new LinearLayout(context);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        mParentView.setLayoutParams(params);
        mParentView.setBackgroundColor(Color.parseColor("#104B99"));
        mParentView.getBackground().setAlpha(245);
        mParentView.setOrientation(LinearLayout.VERTICAL);
        mParentView.setGravity(Gravity.CENTER_HORIZONTAL);
        mTextView = new TextView(context);
        LinearLayout.LayoutParams mLayoutParams = new LinearLayout.LayoutParams(370, 55);
        mLayoutParams.topMargin = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 10, context.getResources().getDisplayMetrics());
        mLayoutParams.bottomMargin = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 10, context.getResources().getDisplayMetrics());
        mTextView.setLayoutParams(mLayoutParams);
//        mTextView.setText((mReboot ? com.android.internal.R.string.reboot_progress : com.android.internal.R.string.shutdown_progress));
        mTextView.setTextSize((int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 6, context.getResources().getDisplayMetrics()));
        mTextView.setGravity(Gravity.CENTER | Gravity.TOP);
        mTextView.setTextColor(Color.parseColor("#FFFFFF"));
        this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.setContentView(mParentView);
        this.setCancelable(false);
//        this.getWindow().setType(WindowManager.LayoutParams.TYPE_KEYGUARD_DIALOG);
        this.getWindow().setGravity(Gravity.CENTER);
        this.getWindow().setBackgroundDrawable(mContext.getResources().getDrawable(com.android.internal.R.color.transparent));

        mHandler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                if (mEvProgressView != null && (mEvProgressView.getParent()) != null) {
                    ((ViewGroup) mEvProgressView.getParent()).removeView(mEvProgressView);
                }
                if (mTextView != null && (mTextView.getParent()) != null) {
                    ((ViewGroup) mTextView.getParent()).removeView(mTextView);
                }
                mCount = (mCount >= EvProgressView.MAX_POINT_NUMBER - 1) ? 0 : mCount + 1;
                mEvProgressView = new EvProgressView(mContext, mCount);
                LinearLayout.LayoutParams mLayoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                mLayoutParams.topMargin = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 15, mContext.getResources().getDisplayMetrics());
                mEvProgressView.setLayoutParams(mLayoutParams);
                mParentView.addView(mEvProgressView);
                mParentView.addView(mTextView);
                mHandler.sendEmptyMessageDelayed(MSG_UPDATE_LOADING_VIEW, PERIOD_UPDATE_LOADING_VIEW);
            }
        };
    }

    @Override
    public void show() {
        mHandler.sendEmptyMessage(MSG_UPDATE_LOADING_VIEW);
        super.show();
    }

    @Override
    public void dismiss() {
        mHandler.removeMessages(MSG_UPDATE_LOADING_VIEW);
        super.dismiss();
    }

    public class EvProgressView extends View {

        public static final int MAX_COLOR_ALPHA = 255;
        public static final int MAX_POINT_NUMBER = 12;
        public static final int COLOR_ALPHA_DESCEND = 18;

        private int mIndex;
        private Paint mPaint;

        public EvProgressView(Context context, int index) {
            super(context);
            mIndex = index;
            mPaint = new Paint();
        }

        @Override
        protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
            int widthSize = MeasureSpec.getSize(widthMeasureSpec);
            int widthMode = MeasureSpec.getMode(widthMeasureSpec);
            int heightSize = MeasureSpec.getSize(heightMeasureSpec);
            int heightMode = MeasureSpec.getMode(heightMeasureSpec);

            int width;
            int height;

            if (widthMode == MeasureSpec.EXACTLY) {
                width = widthSize;
            } else {
                width = 100;
            }

            if (heightMode == MeasureSpec.EXACTLY) {
                height = heightSize;
            } else {
                height = 100;
            }
            setMeasuredDimension(width, height);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            mPaint.setStrokeWidth(1);
            mPaint.setAntiAlias(true);
            mPaint.setStyle(Paint.Style.FILL_AND_STROKE);
            int width = this.getWidth() / 2;
            int height = this.getHeight() / 2;
            int radioCircle = 38;
            int radioPoint = 5;
            int count = 0;
            mPaint.setColor(getResources().getColor(android.R.color.white));
            for (int i = 0; i < MAX_POINT_NUMBER; i++) {
                if (i < MAX_POINT_NUMBER - mIndex) {
                    mPaint.setAlpha(MAX_COLOR_ALPHA - COLOR_ALPHA_DESCEND * mIndex - COLOR_ALPHA_DESCEND * i);
                } else {
                    mPaint.setAlpha(MAX_COLOR_ALPHA - COLOR_ALPHA_DESCEND * count++);
                }
                canvas.drawCircle(
                        (float) (width - radioCircle * Math.sin(30.0 * i * Math.PI / 180.0)),
                        (float) (height - radioCircle * Math.cos(30.0 * i * Math.PI / 180.0)),
                        radioPoint,
                        mPaint
                );
            }
        }
    }
}